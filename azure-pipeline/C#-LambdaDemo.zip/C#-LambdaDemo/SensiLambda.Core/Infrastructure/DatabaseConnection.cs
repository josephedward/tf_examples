﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace SensiLambda.Core.Infrastructure
{
    public class DatabaseConnection
    {
        private string _connectionString;
        
        public DatabaseConnection()
        {

        }

        public DatabaseConnection(string fullConnectionString)
        {
            _connectionString = fullConnectionString;
        }

        [JsonPropertyName("database")]
        public string Database { get; set; }

        [JsonPropertyName("password")]
        public string Password { get; set; }

        [JsonPropertyName("engine")]
        public string Engine { get; set; }
        
        [JsonPropertyName("port")]
        public int Port { get; set; }
        
        [JsonPropertyName("DbInstanceIdentifier")]
        public string DbInstanceIdentifier { get; set; }

        [JsonPropertyName("host")]
        public string Host { get; set; }

        [JsonPropertyName("username")]
        public string Username { get; set; }

        public override string ToString()
        {
            if (!string.IsNullOrEmpty(_connectionString))
            {
                return _connectionString;
            }

            return $"server={Host};post={Port};database={Database};user={Username};password={Password};Persist Security Info=False;Connect Timeout=300";
        }
    }
}

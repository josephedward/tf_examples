'use strict';

const AWS = require('aws-sdk');


module.exports.handler = (event, context, callback) => {
  callback(null, `done`);
};
